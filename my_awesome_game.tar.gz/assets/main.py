import pygame
import random
import asyncio

async def main():
    pygame.init()

    WIDTH, HEIGHT = 800, 600
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Apple Collector")
    clock = pygame.time.Clock()

    BACKGROUND = (30, 30, 40)
    RED = (255, 0, 0)
    BLUE = (0, 122, 255)
    GREEN = (0, 255, 0)
    WHITE = (255, 255, 255)
    BROWN = (139, 69, 19)

    # 2. BASE64 CONVERTED SPRITE IMAGE (32x32 pixel ball)
    # This raw string replaces the need for an external "ball.png" 
    RAW_BASE64_SPRITE = ("UklGRjQCAABXRUJQVlA4TCcCAAAv1gA4AMegNLKdKAm3A4mMhFJwDPXRCjWh7zbUxrYNvf8t8Zd5qVCjutKISnYMIklq1GQN2MMbHtOH+Q+A/wP4TQRuLve+xEhMbKoGFIkF/wmJRJiwYUk2bKVlSv+tu+k2DHQdEyRIkhwpUk0DI45WScty/f+rkVYS7L2F2UT0fwKWL/+/47agsOCbAqOz0+jsNL4VMFaK3dRO4/uBXdAojDu+H9iNvjMwVg7NzX026qwcWoM2P8UZH1xZ2emsFGvQg23UaUxxKyv7qLNSOBt7cGXnSqcxu1XughHpwcb+5MbEZqzcTZ3TX9ZpzGTGB58gf5jG7FY4R0Ya85zNX3lh4VDhSiEbn9DozFAWHDLeR/cUcuWFhaLwQiGFbBxqdBqXn2SCqbTRBw8Uh+CD4sGVF5bgyguFrEEfrcFc5cHKb4xEH0ERXXmZL55oweVnmm9k4WN0G6yMRIfsFZefc4K5UEghS3AbrDQ6O52dn7wGxfIrzjJGIcVco7Oz0Vi4ZeGFOU0aa1A0OoXRKTobjZ3boDAuv/Ys42yjTiGd4sjCbbDwwtzXWSkahXEbLLzQuPwG5hZpnOM0OnvQacELLZjs5orGSKMHjR40pjh5HrVgZUQ2WrDRginuwBNvPDEiK9uoM+LMc2cegmcOyUoPVgpnZXYznnkInnkLnhh5yeU3MMEcRk/zxYGn+XnuOzejH6Mbik3wY3TDFCftZ7r8VuaWL/9/+f9vPAA="
    )










    # Convert Raw Base64 string back into a Pygame Surface
    sprite_surface = pygame.image.load("assets/player.png").convert_alpha()



    class PlayerSprite(pygame.sprite.Sprite):
        def __init__(self, x, y):
            super().__init__()

            self.image = pygame.transform.scale(sprite_surface, (70, 70))

            self.rect = self.image.get_rect(topleft=(x, y))

            self.x = 0
            self.y = 0
            self.speed = 6
            self.gravity = 0.8
            self.jump = -19
            self.is_grounded = False

        def update(self, platforms):
            keys = pygame.key.get_pressed()

            self.x = 0

            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                self.x = -self.speed

            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                self.x = self.speed

            if (keys[pygame.K_UP] or keys[pygame.K_w]) and self.is_grounded:
                self.y = self.jump
                self.is_grounded = False

            self.y += self.gravity

            self.rect.x += self.x

            if self.rect.left < 0:
                self.rect.left = 0

            if self.rect.right > WIDTH:
                self.rect.right = WIDTH

            self.rect.y += self.y

            self.is_grounded = False

            for platform in platforms:
                if self.rect.colliderect(platform):

                    if self.y > 0:
                        self.rect.bottom = platform.top
                        self.y = 0
                        self.is_grounded = True

                    elif self.y < 0:
                        self.rect.top = platform.bottom
                        self.y = 0


    player = PlayerSprite(380, 100)

    all_sprites = pygame.sprite.Group()
    all_sprites.add(player)

    platforms = [
        pygame.Rect(0, 550, 800, 50),
        pygame.Rect(100, 400, 250, 20),
        pygame.Rect(450, 300, 250, 20)
    ]

    apples = []

    for i in range(10):
        x = random.randint(50, 750)
        y = random.randint(50, 500)
        apples.append(pygame.Rect(x, y, 16, 16))

    font = pygame.font.Font(None, 36)

    running = True

    while running:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        player.update(platforms)

        for apple in apples[:]:
            if player.rect.colliderect(apple):
                apples.remove(apple)

        screen.fill(BACKGROUND)

        for platform in platforms:
            pygame.draw.rect(screen, BLUE, platform)

        for apple in apples:
            pygame.draw.circle(screen, RED, apple.center, 8)

            pygame.draw.rect(
                screen,
                BROWN,
                (apple.centerx - 2, apple.centery - 13, 4, 7)
            )

            filled_rect = (
                apple.centerx + 2,
                apple.centery - 16,
                10,
                7
            )

            pygame.draw.ellipse(
                screen,
                GREEN,
                filled_rect
            )

        all_sprites.draw(screen)

        score_text = font.render(
            "Apples left: " + str(len(apples)),
            True,
            WHITE
        )

        screen.blit(score_text, (20, 20))

        if len(apples) == 0:
            win_text = font.render(
                "You collected all the apples!",
                True,
                GREEN
            )
            screen.blit(win_text, (220, 60))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)
        

    pygame.quit()


asyncio.run(main())
